#include "producer.h"


extern int producer_counter;

message produce()
{
    struct message message;
    message.size = rand() % 256;
    message.type = rand() % 0x8;

    for(ushort i = 0; i < message.size; i++){
        message.data[i] = rand() % 256;
    }

    message.hash = 0;
    message.hash = createHash(&message);
    return message;
}

void createProducer()
{
    switch (producers[producer_counter] = fork())
    {
    case -1:
        perror("fork");
        break;
    
    default:
        producer_counter++;
        return;
    }

    while (true)
    {
        putIntoQueue(produce());
    }
    

}

void putIntoQueue(message message)
{
    sem_wait(&free_space);
    sem_wait(&mutex);
    printf("message produced");
    int msgQue = msgget(queue, 0666 | IPC_CREAT);
    if(msgQue == -1)
    {
        printf("CANT PUT MESSAGE\n");
        perror("msgget");
    }
    msgsnd(msgQue, &message, sizeof(message), 0);
    sem_post(&mutex);
    sem_post(&items);
}
