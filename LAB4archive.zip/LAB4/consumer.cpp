#include "consumer.h"


void consume(message message)
{
    ushort msg_hash = message.hash;
    message.hash = 0;
    ushort cur_hash = createHash(&message);

    if(msg_hash != cur_hash){
        fprintf(stderr, "error: corrupted message consumed: %d -> %d\n", msg_hash, cur_hash);
    }

    message.hash = msg_hash;
}

void createConsumer()
{
    switch (consumers[consumer_counter] = fork())
    {
    case -1:
        perror("fork");
        break;
    
    default:
        consumer_counter++;
        return;
    }

    while (true)
    {
        showMessage(getMessage());
        sleep(5);
    }
}

void showMessage(message message)
{
    printf("consumer %d\n"
            "message:\n"
            "\ttype: %d\n"
            "\thash: %hu\n"
            "\tsize: %d\n\n",
            getpid(), message.type, message.hash, message.size);
}

message getMessage()
{
    message message;
    int msgQue = msgget(queue, 0666 | IPC_CREAT);
    if(msgQue == -1)
    {
        printf("CANT PUT MESSAGE\n");
        perror("msgget");
    }
    sem_wait(&items);
    sem_wait(&mutex);
    msgrcv(msgQue, &message, sizeof(message), 1, 0);
    printf("recieved");
    sem_post(&mutex);
    sem_post(&free_space);
    return message;
}

